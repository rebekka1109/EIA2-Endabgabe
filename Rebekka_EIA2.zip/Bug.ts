namespace GardenSimulation {
    export class Bug {
        constructor() {
            //
        }

    }
}