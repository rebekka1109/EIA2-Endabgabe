var GardenSimulation;
(function (GardenSimulation) {
    var Bug = /** @class */ (function () {
        function Bug() {
            //
        }
        return Bug;
    }());
    GardenSimulation.Bug = Bug;
})(GardenSimulation || (GardenSimulation = {}));
//# sourceMappingURL=Bug.js.map